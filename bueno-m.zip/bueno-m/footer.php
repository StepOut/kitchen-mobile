			
            </div>
		</div>
        <!-- /Content -->
		<?php wp_footer(); ?>
	</body>
</html>