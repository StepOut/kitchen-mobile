<div class="post-content">
<?php mobiliwp_excerpt();?>
</div>