<?php
/*
	Plugin Name: Webbu Mobile First - Mobili Theme Switcher Mode
	Plugin URI: http://themeforest.net/user/Webbu
	Description: This plugin allow use mobili theme with WP Theme Switcher plugin
	Version: 1.0.0
	Author: Webbu
	Author URI: http://themeforest.net/user/Webbu
*/
// Social Icons
include 'custom-widgets.php';

// Register Mobili Menus
function register_mobili_menu_plgmode()
{
    register_nav_menus(array( 
        'mobili-left-menu' => __('Mobili Left Menu', 'mobilit2d'),
        'mobili-right-menu' => __('Mobili Right Menu', 'mobilit2d'), 
    ));
}
add_action('init', 'register_mobili_menu_plgmode');

// Register Mobili Side Bars
if (function_exists('register_sidebar'))
{
    // Define Sidebar Widget Area 1
    register_sidebar(array(
        'name' => __('MOBILI Right Widget Area', 'mobilit2d'),
        'description' => __('MOBILI Right Widget Area', 'mobilit2d'),
        'id' => 'mobili-widget-area-1',
        'before_widget' => '<div id="%1$s" class="%2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3><div class="widgetheader">',
        'after_title' => '</div></h3>'
    ));
	
	// Define Sidebar Widget Area 2
    register_sidebar(array(
        'name' => __('MOBILI Left Widget Area', 'mobilit2d'),
        'description' => __('MOBILI Left Widget Area', 'mobilit2d'),
        'id' => 'mobili-widget-area-2',
        'before_widget' => '<div id="%1$s" class="%2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3><div class="widgetheader">',
        'after_title' => '</div></h3>'
    ));

}

?>